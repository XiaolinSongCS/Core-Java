package com.xiaolinsong;

import java.util.List;

/**
 * Created by xiaolinsong on 4/19/17.
 */
public interface ISaveable {
    List<String> write();
    void read(List<String> saveValues);

}
